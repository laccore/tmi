package umnwebtemplate

class CssController {

    def template = { }

    def print = { }

}
